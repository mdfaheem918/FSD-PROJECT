/* Preact-powered notification state. The rest of the existing UI remains framework-compatible. */
(function(){
  const fallback = document.getElementById('toast');
  if (!window.preact || !window.preactHooks || !fallback) return;
  const { h, render } = window.preact;
  const { useState, useEffect } = window.preactHooks;
  function ToastHost(){
    const [notice,setNotice]=useState('');
    useEffect(()=>{ if(!notice)return; const timer=setTimeout(()=>setNotice(''),2600); return ()=>clearTimeout(timer); },[notice]);
    window.RoamToast={show:setNotice};
    return h('div',{class:'toast'+(notice?' show':''),'role':'status','aria-live':'polite'},notice);
  }
  const mount=document.createElement('div'); mount.id='roam-toast-root'; fallback.replaceWith(mount); render(h(ToastHost),mount);
})();
