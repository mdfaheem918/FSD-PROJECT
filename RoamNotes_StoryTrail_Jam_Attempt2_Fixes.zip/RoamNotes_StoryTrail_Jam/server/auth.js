const jwt = require('jsonwebtoken');
const COOKIE_NAME = 'roamnotes_session';
function cookieOptions() {
  return { httpOnly:true, secure:process.env.NODE_ENV === 'production', sameSite:'strict', path:'/', maxAge:7*24*60*60*1000 };
}
function signToken(user) {
 const secret = process.env.JWT_SECRET;
 if (!secret || secret.length < 32) throw new Error('JWT_SECRET must contain at least 32 characters. Set it in your environment.');
 return jwt.sign({ id:user.id, role:user.role, name:user.name }, secret, { expiresIn:'7d', issuer:'roamnotes', audience:'roamnotes-web' });
}
function setSessionCookies(res, user) {
 const token = signToken(user);
 const csrf = require('crypto').randomBytes(32).toString('hex');
 res.cookie(COOKIE_NAME, token, cookieOptions());
 res.cookie('roamnotes_csrf', csrf, { httpOnly:false, secure:process.env.NODE_ENV === 'production', sameSite:'strict', path:'/', maxAge:7*24*60*60*1000 });
}
function clearSessionCookies(res) {
 const opts = { path:'/', sameSite:'strict', secure:process.env.NODE_ENV === 'production' };
 res.clearCookie(COOKIE_NAME, { ...opts, httpOnly:true });
 res.clearCookie('roamnotes_csrf', opts);
}
function optionalAuth(req,res,next) {
 const token = req.cookies?.[COOKIE_NAME];
 if (token) {
  try { req.user = jwt.verify(token, process.env.JWT_SECRET, { issuer:'roamnotes', audience:'roamnotes-web' }); }
  catch (_) { clearSessionCookies(res); return res.status(401).json({ error:'Your session is invalid or expired. Please sign in again.' }); }
 }
 next();
}
function requireAuth(req,res,next) { if (!req.user) return res.status(401).json({error:'Please sign in to continue.'}); next(); }
module.exports = { signToken, setSessionCookies, clearSessionCookies, optionalAuth, requireAuth, COOKIE_NAME };
