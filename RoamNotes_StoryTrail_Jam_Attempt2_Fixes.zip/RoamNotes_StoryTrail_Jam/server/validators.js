const { z } = require('zod');
const safeText = (max) => z.string().trim().min(1).max(max);
const imageUrl = z.string().trim().max(2048).url().refine(v => /^https:\/\//i.test(v), 'Image URL must use HTTPS');
const stopSchema = z.object({
 name: safeText(100), lat: z.number().min(-90).max(90), lon: z.number().min(-180).max(180),
 day: z.number().int().min(1).max(60), mode: safeText(40), tip: z.string().trim().max(500).default('')
});
const storySchema = z.object({
 title: safeText(90), destination: safeText(120), region: z.enum(['Himalayas','Coastal','Heritage','Northeast','Desert']),
 style: z.enum(['Budget Backpacking','Trekking','Road Trip','Slow Travel','Luxury']),
 budget: z.number().int().min(0).max(100000000), image: imageUrl,
 description: safeText(5000), days: z.number().int().min(1).max(60).default(2),
 stops: z.array(stopSchema).min(2).max(30),
 costs: z.object({ Stay:z.number().int().min(0), Travel:z.number().int().min(0), Food:z.number().int().min(0), 'Entry fees':z.number().int().min(0), Other:z.number().int().min(0) })
});
const registerSchema = z.object({ name:safeText(60), email:z.string().trim().email().max(254), password:z.string().min(8).max(72) });
const loginSchema = z.object({ email:z.string().trim().email().max(254), password:z.string().min(1).max(72) });
const commentSchema = z.object({ body:safeText(500) });
module.exports = { storySchema, registerSchema, loginSchema, commentSchema };
