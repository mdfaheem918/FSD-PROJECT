require('dotenv').config();
const db=require('./db');
const email=String(process.argv[2]||'').trim().toLowerCase();
if(!email){console.error('Usage: node server/create-moderator.js user@example.com');process.exit(1)}
const result=db.prepare("UPDATE users SET role='moderator' WHERE email=?").run(email);
if(!result.changes)console.error('No account found for that email. Ask the user to register first.');
else console.log(`Moderator role granted to ${email}`);
db.close();
