const path = require('path');
const Database = require('better-sqlite3');
const db = new Database(process.env.DB_PATH || path.join(__dirname, 'roamnotes.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL UNIQUE,
 password_hash TEXT NOT NULL, role TEXT NOT NULL DEFAULT 'user', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS stories (
 id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, destination TEXT NOT NULL,
 region TEXT NOT NULL, style TEXT NOT NULL, budget INTEGER NOT NULL, days INTEGER NOT NULL DEFAULT 2,
 likes INTEGER NOT NULL DEFAULT 0, author_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
 author TEXT NOT NULL, avatar TEXT NOT NULL, read_time INTEGER NOT NULL DEFAULT 4,
 image TEXT NOT NULL, description TEXT NOT NULL, stops_json TEXT NOT NULL, costs_json TEXT NOT NULL,
 is_seed INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS comments (
 id INTEGER PRIMARY KEY AUTOINCREMENT, story_id INTEGER NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
 user_id INTEGER REFERENCES users(id) ON DELETE SET NULL, author TEXT NOT NULL, body TEXT NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS likes (
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 story_id INTEGER NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
 PRIMARY KEY(user_id, story_id)
);
CREATE TABLE IF NOT EXISTS bookmarks (
 user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
 story_id INTEGER NOT NULL REFERENCES stories(id) ON DELETE CASCADE,
 PRIMARY KEY(user_id, story_id)
);
CREATE INDEX IF NOT EXISTS idx_stories_created ON stories(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_comments_story ON comments(story_id, created_at);
`);
module.exports = db;
