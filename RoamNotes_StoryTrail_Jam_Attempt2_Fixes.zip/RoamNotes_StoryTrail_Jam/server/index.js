require('dotenv').config();
const express = require('express');
const path = require('path');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cookieParser = require('cookie-parser');
const crypto = require('crypto');
const pino = require('pino');
const pinoHttp = require('pino-http');
const bcrypt = require('bcryptjs');
const db = require('./db');
const seedStories = require('./seed-data');
const { storySchema, registerSchema, loginSchema, commentSchema } = require('./validators');
const { setSessionCookies, clearSessionCookies, optionalAuth, requireAuth } = require('./auth');

const app = express();
const logger = pino({ level:process.env.LOG_LEVEL || (process.env.NODE_ENV === 'production' ? 'info' : 'debug'), redact:{ paths:['req.headers.cookie','req.headers.authorization','res.headers.set-cookie'], censor:'[REDACTED]' } });
app.use(pinoHttp({ logger, genReqId: req => req.headers['x-request-id'] || crypto.randomUUID(), customLogLevel:(res,err)=>err || res.statusCode >= 500 ? 'error' : res.statusCode >= 400 ? 'warn' : 'info' }));
app.use(helmet({ contentSecurityPolicy:false }));
// The frontend and API are served from the same origin; no permissive cross-origin policy is needed.
app.use(express.json({ limit:'1mb' }));
app.use(cookieParser());
app.use((req,res,next)=>{ if(/^\/(server|tests|node_modules)(\/|$)/i.test(req.path) || /^\/(\.env|package(?:-lock)?\.json|README\.md|jest\.config\.js|\.gitignore)$/i.test(req.path)) return res.sendStatus(404); next(); });
app.use(express.static(path.join(__dirname,'..'),{dotfiles:'deny',index:'index.html'}));
app.use('/api/auth', rateLimit({ windowMs:15*60*1000, limit:20, standardHeaders:true, legacyHeaders:false, message:{error:'Too many authentication attempts. Please try again later.'} }));
app.use('/api', rateLimit({ windowMs:60*1000, limit:180, standardHeaders:true, legacyHeaders:false, message:{error:'Request limit reached. Please wait and try again.'} }));
app.use('/api', (req,res,next)=>{
 const safe = ['GET','HEAD','OPTIONS'].includes(req.method);
 const authBootstrap = req.path === '/auth/login' || req.path === '/auth/register';
 if (safe || authBootstrap) return next();
 const cookie = req.cookies?.roamnotes_csrf || ''; const header = req.get('x-csrf-token') || '';
 if (!cookie || !header || cookie.length !== header.length || !crypto.timingSafeEqual(Buffer.from(cookie),Buffer.from(header))) return res.status(403).json({error:'Security token missing or invalid. Refresh the page and try again.'});
 next();
});

function seedDatabase() {
 const count = db.prepare('SELECT COUNT(*) AS count FROM stories WHERE is_seed=1').get().count;
 if (count) return;
 const insert = db.prepare(`INSERT INTO stories (title,destination,region,style,budget,days,likes,author,avatar,read_time,image,description,stops_json,costs_json,is_seed) VALUES (@title,@destination,@region,@style,@budget,@days,@likes,@author,@avatar,@read,@image,@description,@stops,@costs,1)`);
 const insertComments=db.prepare('INSERT INTO comments(story_id,author,body) VALUES(?,?,?)');
 const tx = db.transaction(items => items.forEach(s => { const result=insert.run({ ...s, stops:JSON.stringify(s.stops), costs:JSON.stringify(s.costs) }); (s.comments||[]).forEach(body=>insertComments.run(Number(result.lastInsertRowid),s.author,body)); }));
 tx(seedStories);
}
seedDatabase();
function parseStory(row, userId) {
 if (!row) return null;
 const comments = db.prepare('SELECT id,author,body,created_at AS createdAt FROM comments WHERE story_id=? ORDER BY id').all(row.id);
 return { id:row.id, title:row.title, destination:row.destination, region:row.region, style:row.style, budget:row.budget,
  days:row.days, likes:row.likes, author:row.author, avatar:row.avatar, read:row.read_time, image:row.image,
  description:row.description, stops:JSON.parse(row.stops_json), costs:JSON.parse(row.costs_json), comments:comments.map(c=>c.body),
  commentItems:comments, userCreated:!row.is_seed, ownerId:row.author_id, canDelete:!!userId && (row.author_id===userId), isLiked:!!userId && !!db.prepare('SELECT 1 FROM likes WHERE user_id=? AND story_id=?').get(userId,row.id),
  isSaved:!!userId && !!db.prepare('SELECT 1 FROM bookmarks WHERE user_id=? AND story_id=?').get(userId,row.id), createdAt:row.created_at };
}
const getStory = db.prepare('SELECT * FROM stories WHERE id=?');
function validate(schema, req, res) { const result=schema.safeParse(req.body); if(!result.success){res.status(400).json({error:'Please correct the highlighted information.',details:result.error.issues.map(i=>({field:i.path.join('.'),message:i.message}))});return null;} return result.data; }

app.get('/api/health',(req,res)=>res.json({status:'ok',service:'RoamNotes API'}));
app.get('/api/csrf',(req,res)=>{ const token=crypto.randomBytes(32).toString('hex'); res.cookie('roamnotes_csrf',token,{httpOnly:false,secure:process.env.NODE_ENV==='production',sameSite:'strict',path:'/',maxAge:7*24*60*60*1000}); res.json({csrfToken:token}); });
app.post('/api/auth/register', async (req,res,next)=>{ try {
 const data=validate(registerSchema,req,res); if(!data)return;
 const email=data.email.toLowerCase(); if(db.prepare('SELECT id FROM users WHERE email=?').get(email))return res.status(409).json({error:'An account with this email already exists.'});
 const hash=await bcrypt.hash(data.password,12); const result=db.prepare('INSERT INTO users(name,email,password_hash) VALUES(?,?,?)').run(data.name,email,hash);
 const user={id:Number(result.lastInsertRowid),name:data.name,email,role:'user'}; setSessionCookies(res,user); res.status(201).json({user});
 } catch(e){next(e)} });
app.post('/api/auth/login', async (req,res,next)=>{ try {
 const data=validate(loginSchema,req,res); if(!data)return;
 const user=db.prepare('SELECT * FROM users WHERE email=?').get(data.email.toLowerCase());
 if(!user || !(await bcrypt.compare(data.password,user.password_hash)))return res.status(401).json({error:'Email or password is incorrect.'});
 setSessionCookies(res,user); res.json({user:{id:user.id,name:user.name,email:user.email,role:user.role}});
 } catch(e){next(e)} });
app.post('/api/auth/logout',(req,res)=>{clearSessionCookies(res);res.json({message:'Signed out.'})});
app.get('/api/auth/me',optionalAuth,requireAuth,(req,res)=>{const user=db.prepare('SELECT id,name,email,role FROM users WHERE id=?').get(req.user.id); if(!user)return res.status(401).json({error:'Account not found.'});res.json({user})});

app.get('/api/stories',optionalAuth,(req,res)=>{
 const page=Math.max(1,Number.parseInt(req.query.page,10)||1), limit=Math.min(24,Math.max(1,Number.parseInt(req.query.limit,10)||9));
 const q=String(req.query.q||'').slice(0,120), region=String(req.query.region||''), style=String(req.query.style||''), sort=String(req.query.sort||'newest');
 const allowedSort={newest:'created_at DESC',popular:'likes DESC, created_at DESC',budget:'budget ASC'};
 const where=[], params=[]; if(q){where.push('(title LIKE ? OR destination LIKE ? OR author LIKE ?)');params.push(`%${q}%`,`%${q}%`,`%${q}%`)}
 if(region){where.push('region=?');params.push(region)} if(style){where.push('style=?');params.push(style)}
 const clause=where.length?`WHERE ${where.join(' AND ')}`:''; const total=db.prepare(`SELECT COUNT(*) count FROM stories ${clause}`).get(...params).count;
 const rows=db.prepare(`SELECT * FROM stories ${clause} ORDER BY ${allowedSort[sort]||allowedSort.newest} LIMIT ? OFFSET ?`).all(...params,limit,(page-1)*limit);
 res.json({stories:rows.map(r=>parseStory(r,req.user?.id)),page,limit,total,pages:Math.ceil(total/limit)});
});
app.get('/api/stories/:id',optionalAuth,(req,res)=>{const story=parseStory(getStory.get(Number(req.params.id)),req.user?.id);if(!story)return res.status(404).json({error:'Story not found.'});res.json({story})});
app.post('/api/stories',optionalAuth,requireAuth,(req,res)=>{
 const data=validate(storySchema,req,res);if(!data)return;
 const costsTotal=Object.values(data.costs).reduce((a,b)=>a+b,0); if(costsTotal!==data.budget)return res.status(400).json({error:'The expense breakdown must add up to the total budget.'});
 const user=db.prepare('SELECT name FROM users WHERE id=?').get(req.user.id); const avatar=user.name.split(/\s+/).map(x=>x[0]).join('').slice(0,2).toUpperCase();
 const result=db.prepare(`INSERT INTO stories(title,destination,region,style,budget,days,author_id,author,avatar,read_time,image,description,stops_json,costs_json) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
 .run(data.title,data.destination,data.region,data.style,data.budget,data.days,req.user.id,user.name,avatar,Math.max(1,Math.ceil(data.description.split(/\s+/).length/200)),data.image,data.description,JSON.stringify(data.stops),JSON.stringify(data.costs));
 res.status(201).json({story:parseStory(getStory.get(result.lastInsertRowid),req.user.id)});
});
app.delete('/api/stories/:id',optionalAuth,requireAuth,(req,res)=>{
 const row=getStory.get(Number(req.params.id)); if(!row)return res.status(404).json({error:'Story not found.'});
 if(row.is_seed)return res.status(403).json({error:'Sample community stories cannot be deleted.'});
 if(row.author_id!==req.user.id && req.user.role!=='moderator')return res.status(403).json({error:'You can only delete your own stories.'});
 db.prepare('DELETE FROM stories WHERE id=?').run(row.id);res.json({message:'Story deleted successfully.',id:row.id});
});
app.post('/api/stories/:id/comments',optionalAuth,requireAuth,(req,res)=>{
 const data=validate(commentSchema,req,res);if(!data)return;const row=getStory.get(Number(req.params.id));if(!row)return res.status(404).json({error:'Story not found.'});
 const user=db.prepare('SELECT name FROM users WHERE id=?').get(req.user.id);const result=db.prepare('INSERT INTO comments(story_id,user_id,author,body) VALUES(?,?,?,?)').run(row.id,req.user.id,user.name,data.body);
 res.status(201).json({comment:db.prepare('SELECT id,author,body,created_at AS createdAt FROM comments WHERE id=?').get(result.lastInsertRowid)});
});
app.post('/api/stories/:id/like',optionalAuth,requireAuth,(req,res)=>{
 const id=Number(req.params.id);if(!getStory.get(id))return res.status(404).json({error:'Story not found.'});
 const existing=db.prepare('SELECT 1 FROM likes WHERE user_id=? AND story_id=?').get(req.user.id,id);
 if(existing){db.prepare('DELETE FROM likes WHERE user_id=? AND story_id=?').run(req.user.id,id);db.prepare('UPDATE stories SET likes=MAX(0,likes-1) WHERE id=?').run(id)}
 else{db.prepare('INSERT INTO likes(user_id,story_id) VALUES(?,?)').run(req.user.id,id);db.prepare('UPDATE stories SET likes=likes+1 WHERE id=?').run(id)}
 res.json({liked:!existing,likes:getStory.get(id).likes});
});
app.post('/api/stories/:id/bookmark',optionalAuth,requireAuth,(req,res)=>{
 const id=Number(req.params.id);if(!getStory.get(id))return res.status(404).json({error:'Story not found.'});
 const existing=db.prepare('SELECT 1 FROM bookmarks WHERE user_id=? AND story_id=?').get(req.user.id,id);
 if(existing)db.prepare('DELETE FROM bookmarks WHERE user_id=? AND story_id=?').run(req.user.id,id);else db.prepare('INSERT INTO bookmarks(user_id,story_id) VALUES(?,?)').run(req.user.id,id);
 res.json({saved:!existing});
});
app.get('/api/bookmarks',optionalAuth,requireAuth,(req,res)=>{const rows=db.prepare('SELECT s.* FROM stories s JOIN bookmarks b ON b.story_id=s.id WHERE b.user_id=? ORDER BY b.rowid DESC').all(req.user.id);res.json({stories:rows.map(r=>parseStory(r,req.user.id))})});

app.get('/api/openapi.json',(req,res)=>res.sendFile(path.join(__dirname,'openapi.json')));
app.get('/api/docs',(req,res)=>res.sendFile(path.join(__dirname,'api-docs.html')));
app.use('/api',(req,res)=>res.status(404).json({error:'API endpoint not found.'}));
app.use((err,req,res,next)=>{req.log?.error({err,requestId:req.id},'Unhandled request error');if(res.headersSent)return next(err);const status=err.type==='entity.parse.failed'?400:err.type==='entity.too.large'?413:500;res.status(status).json({error:status===500&&process.env.NODE_ENV==='production'?'An unexpected server error occurred.':err.message||'Internal server error.'})});
const port=Number(process.env.PORT)||3000;
if(require.main===module)app.listen(port,()=>logger.info({port,env:process.env.NODE_ENV||'development'},'RoamNotes server started'));
module.exports={app,db};
