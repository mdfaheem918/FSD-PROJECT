# RoamNotes — StoryTrail Jam (Backend Edition)

A responsive community travel storytelling app built with HTML5, CSS3 and Vanilla JavaScript, now backed by Node.js, Express and SQLite. The project keeps the original Midnight Blue design and four alternate themes while adding server-side persistence, HttpOnly cookie authentication, CSRF protection, authorization, validation, pagination, structured logging, API documentation and automated tests.

## 1. Requirements

- Node.js 18 or newer (Node 20/22 recommended)
- npm
- Internet connection for Google Fonts, Leaflet maps, map tiles and Unsplash images

## 2. Install and run

1. Extract the ZIP and open the `RoamNotes_StoryTrail_Jam` folder in VS Code.
2. Open the VS Code terminal in that folder.
3. Install the dependencies:

   ```bash
   npm install
   ```

4. Copy `.env.example` to `.env` and set a long, private JWT secret (at least 32 characters):

   ```env
   PORT=3000
   JWT_SECRET=put-a-long-random-secret-here-at-least-32-characters
   NODE_ENV=development
   ```

5. Start the server:

   ```bash
   npm start
   ```

6. Open **http://localhost:3000** in Chrome.
7. Open **http://localhost:3000/api/docs** for API documentation or `/api/openapi.json` for the OpenAPI 3.0 specification. Do not open `index.html` directly; the API requires the Express server.

The SQLite database is created automatically at `server/roamnotes.sqlite`. The six sample travel stories are inserted the first time the server starts.

## 3. Account and publishing workflow

1. Select **Sign in** in the navigation.
2. Choose **New here? Create account**, enter your name, email and a password of at least 8 characters.
3. Sign in and publish a story. The server validates the content and saves it to SQLite.
4. Your published story displays **Delete story** on its card and **Delete my story** in its detail view. Confirm the prompt to delete it permanently.
5. Users can only delete their own stories. Sample stories cannot be deleted by regular users.
6. Sign out using the account button in the navigation.

## 4. Moderator account

Moderator permissions are not self-selectable from the registration form. First register the account normally, stop the server, then run:

```bash
node server/create-moderator.js moderator@example.com
```

Replace the email with the registered account's email, then restart the server. Moderators can delete user-created stories for moderation. Do not grant moderator access to ordinary accounts.

## 5. Features

- Community feed with search, region and travel-style filters, sorting and server pagination.
- Six seeded travel stories with routes, day-by-day stops, photos, comments and cost breakdowns.
- Leaflet route maps with numbered stops, clickable stop photos and a tile-provider fallback.
- User registration and login using bcrypt password hashing and signed JWT sessions.
- Story publishing with server-side Zod validation, secure HTTPS image URL validation and expense-total checks.
- Server-persisted comments, likes and bookmarks.
- Owner-only story deletion, with confirmation in the UI and authorization enforced by the API.
- Five visual themes: Midnight Blue, Desert Sunset, Forest Trail, Lavender Haze and Monochrome.
- Responsive layout and API error messages for failed requests.

## 6. Architecture

```text
RoamNotes_StoryTrail_Jam/
├── index.html                 # Semantic page and modal structure
├── styles.css                 # Responsive layout and five themes
├── app.js                     # Frontend interactions and API client
├── package.json               # Runtime and test dependencies
├── .env.example               # Environment variable template
├── server/
│   ├── index.js               # Express app and REST endpoints
│   ├── db.js                  # SQLite schema, indexes and constraints
│   ├── auth.js                # JWT authentication middleware
│   ├── validators.js          # Zod request schemas
│   ├── seed-data.js           # Six sample stories
│   └── create-moderator.js    # Explicit moderator promotion utility
└── tests/
    └── api.test.js            # REST API integration tests
```

### Database tables

- `users`: account, password hash and role.
- `stories`: story details, route stops, budget and owner.
- `comments`: story comments with author and timestamp.
- `likes`: unique user/story pairs to prevent duplicate likes.
- `bookmarks`: unique user/story pairs for personal wishlists.

### Main REST endpoints

| Method | Endpoint | Purpose |
|---|---|---|
| POST | `/api/auth/register` | Register a user |
| POST | `/api/auth/login` | Sign in and receive a JWT |
| GET | `/api/auth/me` | Get the current account |
| GET | `/api/stories` | Search/filter/sort/paginate stories |
| GET | `/api/stories/:id` | Read one story |
| POST | `/api/stories` | Publish a story (authenticated) |
| DELETE | `/api/stories/:id` | Delete own story or moderator-managed story |
| POST | `/api/stories/:id/comments` | Add a comment |
| POST | `/api/stories/:id/like` | Toggle a like |
| POST | `/api/stories/:id/bookmark` | Toggle a bookmark |
| GET | `/api/bookmarks` | Get the signed-in user's wishlist |
| GET | `/api/health` | Check server health |

## 7. Automated tests

Run:

```bash
npm test
```

The Jest + Supertest integration suite covers health checks, invalid image URL rejection, authenticated publishing, feed pagination, comments, likes, bookmarks, ownership checks for deletion and unauthenticated publishing.

## 8. Evaluation report corrections

| Evaluation report issue | Change in this version |
|---|---|
| Missing Node.js/Express backend | Express REST API and SQLite persistence |
| No automated tests | Jest and Supertest integration suite |
| Weak external map error handling | Leaflet initialization guard and alternate tile layer fallback |
| No Publish Story image URL validation | HTTPS URL validation on the server plus browser form constraint |
| Limited input validation | Zod validation for auth, stories, stops and comments |
| No authentication | Registration, login, bcrypt password hashes and JWT middleware |
| Weak authorization | Owner-only delete and moderator role check enforced server-side |
| No pagination | API pagination and Load more stories control |
| Concentrated data logic | Separate database, authentication, validation and seed modules |

## 9. Notes and limitations

- The backend and tests require `npm install`; this project is not a static-file-only website anymore.
- The SQLite database is local to the machine running the server. For public deployment, use a managed database, HTTPS, a secure environment secret and a production CORS/origin policy.
- JWT tokens are stored in browser local storage for this academic demo. A production deployment should consider secure, HttpOnly cookies and CSRF protections.
- Sample coordinates, budgets and destination advice are illustrative. Verify details before travelling.
- The map and photos use third-party internet services and may not load offline.


## 6. Security and operations (Attempt #2 improvements)

- JWTs are stored only in a server-issued `HttpOnly`, `SameSite=Strict` session cookie; browser JavaScript cannot read the JWT. Production cookies also set `Secure` (serve the site over HTTPS).
- State-changing API requests require a double-submit CSRF token in the `X-CSRF-Token` header.
- Authentication endpoints and the wider API have separate rate limits.
- Pino and pino-http produce structured JSON request and error logs. Sensitive cookie and authorization headers are redacted. Set `LOG_LEVEL` to control verbosity.
- API documentation is available at `/api/docs` and the machine-readable OpenAPI file at `/api/openapi.json`.
- Preact is used for reactive toast-notification state, while the existing frontend is retained to avoid a risky full UI rewrite.

## 7. Tests

Run `npm test`. The API suite covers cookie-based sessions, CSRF rejection, validation, story creation, pagination, comments, likes, bookmarks and ownership-based deletion.

### Deployment secret management

Never commit `.env` or production credentials. For deployment, inject `JWT_SECRET` and database credentials from the hosting provider's secret manager (for example, AWS Secrets Manager, Azure Key Vault, Google Secret Manager, or the platform's encrypted environment-variable store). Rotate secrets if they are exposed. Set `NODE_ENV=production`, terminate HTTPS at the hosting platform, and use a persistent encrypted volume or managed database for SQLite data.
