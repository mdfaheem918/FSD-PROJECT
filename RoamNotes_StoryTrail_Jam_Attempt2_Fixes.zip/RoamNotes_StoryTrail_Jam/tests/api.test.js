process.env.NODE_ENV = 'test';
process.env.JWT_SECRET = 'test-secret-that-is-long-enough-for-json-web-token';
process.env.DB_PATH = ':memory:';
const request = require('supertest');
const { app, db } = require('../server');

describe('RoamNotes REST API — cookie sessions and CSRF', () => {
 const userA=request.agent(app), userB=request.agent(app);
 let csrfA, csrfB, storyId, sessionCookieA;
 const validStory = {
  title:'A weekend in Araku', destination:'Araku Valley, Andhra Pradesh', region:'Heritage', style:'Budget Backpacking', budget:1000, days:2,
  image:'https://images.unsplash.com/photo-1470770841072-f978cf4d019e', description:'A short sample journey with clear stops and a budget.',
  stops:[{name:'Araku Station',lat:18.3273,lon:82.8775,day:1,mode:'Train',tip:'Arrive in the morning.'},{name:'Coffee Museum',lat:18.326,lon:82.88,day:2,mode:'Walk',tip:'Try local coffee.'}],
  costs:{Stay:300,Travel:250,Food:250,'Entry fees':100,Other:100}
 };
 const write=(agent,csrf,url,body)=>agent.post(url).set('X-CSRF-Token',csrf).send(body);
 beforeAll(async()=>{
  csrfA=(await userA.get('/api/csrf')).body.csrfToken;
  csrfB=(await userB.get('/api/csrf')).body.csrfToken;
  const a=await userA.post('/api/auth/register').send({name:'Chandra User',email:'chandra@example.com',password:'strongpass123'});
  const b=await userB.post('/api/auth/register').send({name:'Other User',email:'other@example.com',password:'strongpass123'});
  expect(a.status).toBe(201); expect(b.status).toBe(201);
  sessionCookieA=(a.headers['set-cookie']||[]).find(x=>x.startsWith('roamnotes_session='));
  csrfA=(await userA.get('/api/csrf')).body.csrfToken;
  csrfB=(await userB.get('/api/csrf')).body.csrfToken;
 });
 afterAll(()=>db.close());
 test('health endpoint responds',async()=>{const r=await request(app).get('/api/health');expect(r.status).toBe(200);expect(r.body.status).toBe('ok')});
 test('session JWT is an HttpOnly cookie and is not returned in JSON',async()=>{
  const r=await userA.get('/api/auth/me'); expect(r.status).toBe(200);
  expect(sessionCookieA).toMatch(/HttpOnly/i);
  expect(r.body.user.email).toBe('chandra@example.com'); expect(r.body.token).toBeUndefined();
 });
 test('rejects unsafe requests without a valid CSRF token',async()=>{const r=await userA.post('/api/stories').send(validStory);expect(r.status).toBe(403)});
 test('rejects invalid image URL and unsafe input',async()=>{const r=await write(userA,csrfA,'/api/stories',{...validStory,image:'javascript:alert(1)'});expect(r.status).toBe(400)});
 test('creates a story and paginates story feed',async()=>{const r=await write(userA,csrfA,'/api/stories',validStory);expect(r.status).toBe(201);storyId=r.body.story.id;expect(r.body.story.canDelete).toBe(true);const feed=await userA.get('/api/stories?page=1&limit=2');expect(feed.status).toBe(200);expect(feed.body.total).toBeGreaterThanOrEqual(7);expect(feed.body.stories.length).toBe(2)});
 test('allows comments, likes and bookmarks for signed-in users',async()=>{const c=await write(userA,csrfA,`/api/stories/${storyId}/comments`,{body:'Helpful travel note'});expect(c.status).toBe(201);const l=await write(userA,csrfA,`/api/stories/${storyId}/like`,{});expect(l.body.liked).toBe(true);const b=await write(userA,csrfA,`/api/stories/${storyId}/bookmark`,{});expect(b.body.saved).toBe(true);const saved=await userA.get('/api/bookmarks');expect(saved.body.stories.some(s=>s.id===storyId)).toBe(true)});
 test('prevents another user from deleting a story',async()=>{const r=await userB.delete(`/api/stories/${storyId}`).set('X-CSRF-Token',csrfB);expect(r.status).toBe(403)});
 test('allows the owner to delete their story',async()=>{const r=await userA.delete(`/api/stories/${storyId}`).set('X-CSRF-Token',csrfA);expect(r.status).toBe(200);const missing=await userA.get(`/api/stories/${storyId}`);expect(missing.status).toBe(404)});
 test('requires authentication for publishing',async()=>{const guest=request.agent(app);const csrf=(await guest.get('/api/csrf')).body.csrfToken;const r=await write(guest,csrf,'/api/stories',validStory);expect(r.status).toBe(401)});
});
